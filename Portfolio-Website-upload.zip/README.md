# My Portfolio Website - Overview 🚀

This repository contains the open-source version of my personal portfolio website.  
Feel free to explore the code and use it for learning and inspiration.

---

## ⚠️ Usage Notice

This project is shared for learning purposes only.

Please do NOT:
- Clone or replicate the full website or design
- Repost it with minor content changes
- Use this project for commercial/client work
- Create tutorials or content using this exact project

If you use parts of the code, you must provide proper credit linking back to the original repository.

Build your own version — don’t just copy.

— Moncy Yohannan

---

## 🛠️ Instructions

I have modified the GSAP Club plugins using trial versions.  
⚠️ Note: Trial plugins cannot be used for production or hosting.

For official GSAP Club plugins, refer here:  
https://gsap.com/docs/v3/Installation/

### Contact form email delivery

The contact form sends messages through the Vercel serverless function in `api/contact.js` and the Resend API. Before deploying:

1. Create a Resend API key and verify the domain used for the sender address.
2. Add these environment variables to the Vercel project and to a local `.env.local` file when testing with `npm run dev`:
   - `RESEND_API_KEY`: the Resend API key (keep it server-side; do not use a `VITE_` prefix).
   - `CONTACT_FROM_EMAIL`: a sender address on the verified domain, such as `Portfolio <hello@example.com>`.
   - `CONTACT_TO_EMAIL`: the inbox that should receive contact messages.
3. Redeploy the project after setting the variables.

Without these settings, the API returns a configuration error and does not send a message.

---

## ⚙️ Tech Stack

React • TypeScript • GSAP • Three.js • WebGL • HTML • CSS • JavaScript

---

## 🎨 Assets Usage

Some 3D assets included in this repository are free to use for learning purposes.

However:

- The original 3D avatar used on my live portfolio is NOT included in this repository
- That avatar is a custom asset created over ~1 month
- It is not open source and not available for reuse

Any usage, extraction, or redistribution of that avatar from my live website is strictly prohibited.

---

![Protfolio-Preview](https://github.com/user-attachments/assets/3c4557e7-6392-4928-b8a9-7b2476ef4edd)

---

## 📄 License

This project is licensed under the Personal Portfolio License (PPL) v1.0.

See the LICENSE file for full details
